const express = require('express');
const crypto = require('crypto');
const path = require('path');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const RESEND_API_KEY = process.env.RESEND_API_KEY;
const RESEND_FROM = process.env.RESEND_FROM;
const TWO_FA_SECRET = process.env.TWO_FA_SECRET;
const CODE_TTL_MS = 10 * 60 * 1000;

app.disable('x-powered-by');
app.use(express.json({ limit: '20kb' }));

function json(res, status, body) {
  res.status(status).json(body);
}

function sign(payload) {
  const raw = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = crypto.createHmac('sha256', TWO_FA_SECRET).update(raw).digest('base64url');
  return `${raw}.${sig}`;
}

function verifyToken(token) {
  const [raw, sig] = String(token || '').split('.');
  if (!raw || !sig || !TWO_FA_SECRET) return null;
  const expected = crypto.createHmac('sha256', TWO_FA_SECRET).update(raw).digest('base64url');
  if (sig.length !== expected.length) return null;
  if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
  let payload;
  try {
    payload = JSON.parse(Buffer.from(raw, 'base64url').toString('utf8'));
  } catch {
    return null;
  }
  if (!payload || !payload.email || !payload.codeHash || !payload.exp || Date.now() > payload.exp) return null;
  return payload;
}

function hashCode(code) {
  return crypto.createHash('sha256').update(String(code)).digest('hex');
}

function validEmail(email) {
  return typeof email === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && email.length <= 254;
}

app.get('/health', (_req, res) => res.status(200).json({ ok: true, service: 'US Soccer Hub' }));

app.options('/api/2fa', (_req, res) => res.sendStatus(204));

app.post('/api/2fa', async (req, res) => {
  if (!RESEND_API_KEY || !RESEND_FROM || !TWO_FA_SECRET) {
    return json(res, 500, { message: '2FA service is missing its server configuration.' });
  }

  const body = req.body || {};
  const email = String(body.email || '').trim().toLowerCase();
  const action = body.action;

  if (!validEmail(email)) return json(res, 400, { message: 'Enter a valid email address.' });

  if (action === 'send') {
    const code = String(crypto.randomInt(0, 1000000)).padStart(6, '0');
    const challenge = sign({
      email,
      codeHash: hashCode(code),
      exp: Date.now() + CODE_TTL_MS
    });

    try {
      const emailResponse = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${RESEND_API_KEY}`
        },
        body: JSON.stringify({
          from: RESEND_FROM,
          to: [email],
          subject: 'US Soccer Hub password reset code',
          text: `Your US Soccer Hub verification code is ${code}. It expires in 10 minutes. If you did not request this code, you can ignore this email.`,
          html: `<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;padding:24px"><h2>US Soccer Hub</h2><p>Your password-reset verification code is:</p><div style="font-size:34px;font-weight:800;letter-spacing:8px;padding:16px 0">${code}</div><p>This code expires in 10 minutes.</p><p>If you did not request this code, you can ignore this email.</p></div>`
        })
      });

      const data = await emailResponse.json().catch(() => ({}));
      if (!emailResponse.ok) {
        return json(res, 502, { message: data.message || 'Resend could not send the verification email.' });
      }

      return json(res, 200, { challenge });
    } catch (error) {
      return json(res, 502, { message: 'The email service could not be reached.' });
    }
  }

  if (action === 'verify') {
    const payload = verifyToken(body.challenge);
    if (!payload || payload.email !== email) {
      return json(res, 400, { verified: false, message: 'That verification code is invalid or expired.' });
    }
    if (hashCode(body.code) !== payload.codeHash) {
      return json(res, 400, { verified: false, message: 'That verification code is invalid or expired.' });
    }
    return json(res, 200, { verified: true });
  }

  return json(res, 400, { message: 'Unknown 2FA action.' });
});

app.use(express.static(path.join(__dirname, 'public'), {
  extensions: ['html'],
  index: 'index.html'
}));

app.use((req, res, next) => {
  if (req.method !== 'GET' && req.method !== 'HEAD') return next();
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`US Soccer Hub running on port ${PORT}`);
});
