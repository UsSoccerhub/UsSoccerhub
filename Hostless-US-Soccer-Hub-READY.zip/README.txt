US SOCCER HUB — HOSTLESS PACKAGE

This package contains the full website plus a Node.js backend that provides /api/2fa.
The website already calls /api/2fa, so the frontend and backend are same-origin when deployed as this single Hostless app.

FILES
- public/index.html = your US Soccer Hub website
- server.js = website server + 6-digit email-code API
- package.json = Node/Express dependencies and start command
- hostless.yaml = Hostless build/start configuration

HOSTLESS SETUP
1. Create a GitHub repository and upload this entire folder, OR upload the project through a Hostless workflow that accepts the source.
2. In Hostless, choose Create New App.
3. Connect the GitHub repository.
4. Build system: Detect automatically / auto.
5. Start command: node server.js (already included in hostless.yaml).
6. Deploy.

ENVIRONMENT VARIABLES
Add these in the Hostless app's Environment Variables section:

RESEND_API_KEY=YOUR_RESEND_API_KEY
RESEND_FROM=YOUR_VERIFIED_RESEND_SENDER
TWO_FA_SECRET=YOUR_LONG_RANDOM_SECRET

Do NOT put RESEND_API_KEY in index.html.

2FA FLOW
1. User enters email in Forgot Password.
2. Website POSTs to /api/2fa with action=send.
3. Server creates a random 6-digit code.
4. Server sends the code through Resend.
5. Server returns a signed challenge without returning the code.
6. User enters the code.
7. Website POSTs to /api/2fa with action=verify.
8. Server verifies the signed challenge and code.

IMPORTANT
- Resend must allow the RESEND_FROM sender for your account.
- The current website's account data is still browser/localStorage based. This backend adds email-code delivery and verification; it does not turn the entire account system into a server database.
- Hostless currently documents a free plan with one always-on app, subject to its current free-resource limits. Check your Hostless dashboard before deploying if your account is on a different billing policy.


IMPORTANT HOSTLESS DEPLOYMENT:
Hostless Apps are deployed from a connected Git repository. Put THESE FILES at the ROOT of the repository (do not put the whole project inside another folder). Create a Hostless App from that repository, use automatic/Nixpicks detection, and use start command: node server.js. Hostless supplies PORT automatically.
