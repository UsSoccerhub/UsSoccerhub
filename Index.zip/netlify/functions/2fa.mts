import type { Context, Config } from "@netlify/functions";
import crypto from "node:crypto";

// ---------------------------------------------------------------------------
// USSoccerDatabase — password recovery / 2FA endpoint
//
// This function is intentionally stateless: it never writes to a database.
// Accounts in this app live in each browser's localStorage, so instead of
// looking anything up server-side, "send" mints a 6-digit code and seals it
// (email + code + expiry) into a signed "challenge" string that the browser
// hands back on "verify". As long as the signature checks out and the code
// hasn't expired, the code is genuine — no storage required in between.
//
// Email delivery uses Resend (https://resend.com) when RESEND_API_KEY is
// configured as a Netlify environment variable. Until that's set up (or if
// Resend refuses the send — e.g. its shared onboarding@resend.dev sender can
// only deliver to the address on the Resend account until a domain is
// verified), the code is returned directly in the response instead, clearly
// flagged as such, so the reset flow still works end to end.
// ---------------------------------------------------------------------------

const CODE_TTL_MS = 10 * 60 * 1000; // 10 minutes
const FALLBACK_SECRET = "ussoccerdatabase-dev-secret-set-AUTH_2FA_SECRET-in-netlify";

function secret(): string {
  return Netlify.env.get("AUTH_2FA_SECRET") || FALLBACK_SECRET;
}

function sign(payload: string): string {
  return crypto.createHmac("sha256", secret()).update(payload).digest("hex");
}

function safeEqual(a: string, b: string): boolean {
  const bufA = Buffer.from(a, "utf8");
  const bufB = Buffer.from(b, "utf8");
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

function encode(payload: string): string {
  return Buffer.from(payload, "utf8").toString("base64url");
}

function decode(value: string): string {
  return Buffer.from(value, "base64url").toString("utf8");
}

function json(body: Record<string, unknown>, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json" },
  });
}

function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

async function sendCodeEmail(to: string, code: string): Promise<{ sent: boolean; reason?: string }> {
  const apiKey = Netlify.env.get("RESEND_API_KEY");
  if (!apiKey) return { sent: false, reason: "no-api-key" };

  try {
    const from = Netlify.env.get("RESEND_FROM") || "USSoccerDatabase <onboarding@resend.dev>";
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "content-type": "application/json",
      },
      body: JSON.stringify({
        from,
        to: [to],
        subject: "Your USSoccerDatabase verification code",
        html:
          '<div style="font-family:Arial,sans-serif;max-width:420px;margin:auto;padding:8px">' +
          '<h2 style="color:#0b5c6b;margin:0 0 6px">USSoccerDatabase</h2>' +
          '<p style="color:#333;margin:0 0 18px">Use this code to reset your password. It expires in 10 minutes.</p>' +
          '<p style="font-size:32px;font-weight:700;letter-spacing:6px;background:#0c2639;color:#39d0c8;padding:16px 18px;border-radius:10px;text-align:center;margin:0 0 18px">' +
          code +
          "</p>" +
          '<p style="font-size:12px;color:#667">If you didn\u2019t request this, you can safely ignore this email.</p>' +
          "</div>",
      }),
    });

    if (!res.ok) {
      const errBody = await res.json().catch(() => null);
      const reason =
        (errBody && (errBody.message || errBody.name)) || `Resend responded with HTTP ${res.status}`;
      return { sent: false, reason };
    }
    return { sent: true };
  } catch (err) {
    return { sent: false, reason: err instanceof Error ? err.message : "Unknown email error" };
  }
}

export default async (req: Request, _context: Context) => {
  if (req.method !== "POST") {
    return json({ message: "Method not allowed." }, 405);
  }

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return json({ message: "Invalid request body." }, 400);
  }

  const action = typeof body.action === "string" ? body.action : "";
  const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";

  if (!email || !isValidEmail(email)) {
    return json({ message: "A valid email address is required." }, 400);
  }

  // ---- action: send --------------------------------------------------
  if (action === "send") {
    const code = String(crypto.randomInt(0, 1_000_000)).padStart(6, "0");
    const expires = Date.now() + CODE_TTL_MS;
    const payload = JSON.stringify({ email, code, expires });
    const challenge = `${encode(payload)}.${sign(payload)}`;

    const result = await sendCodeEmail(email, code);

    if (result.sent) {
      return json({
        challenge,
        emailSent: true,
        message: "Verification code sent to your email.",
      });
    }

    // No email provider configured yet, or the send failed (most commonly
    // because Resend's shared test sender only delivers to the Resend
    // account's own address until a domain is verified). Either way, hand
    // back the code directly so the person isn't stuck, and say plainly
    // that no email actually went out.
    const reason =
      result.reason === "no-api-key"
        ? "Email sending isn\u2019t connected yet, so here\u2019s your code directly."
        : `Couldn\u2019t email the code (${result.reason}), so here\u2019s your code directly.`;

    return json({
      challenge,
      emailSent: false,
      devCode: code,
      message: reason,
    });
  }

  // ---- action: verify --------------------------------------------------
  if (action === "verify") {
    const code = typeof body.code === "string" ? body.code.trim() : "";
    const challenge = typeof body.challenge === "string" ? body.challenge : "";
    const parts = challenge.split(".");

    if (!code || parts.length !== 2) {
      return json({ verified: false, message: "Request a verification code and enter it first." });
    }

    const [payloadEncoded, signature] = parts;
    let payload: string;
    try {
      payload = decode(payloadEncoded);
    } catch {
      return json({ verified: false, message: "That verification code is invalid or expired." });
    }

    if (!safeEqual(signature, sign(payload))) {
      return json({ verified: false, message: "That verification code is invalid or expired." });
    }

    let parsed: { email?: string; code?: string; expires?: number };
    try {
      parsed = JSON.parse(payload);
    } catch {
      return json({ verified: false, message: "That verification code is invalid or expired." });
    }

    if (!parsed.expires || Date.now() > parsed.expires) {
      return json({ verified: false, message: "That code has expired. Send a new one." });
    }
    if (parsed.email !== email) {
      return json({ verified: false, message: "That code was issued for a different email address." });
    }
    if (parsed.code !== code) {
      return json({ verified: false, message: "That verification code is incorrect." });
    }

    return json({ verified: true });
  }

  return json({ message: "Unknown action." }, 400);
};

export const config: Config = {
  path: "/api/2fa",
};
